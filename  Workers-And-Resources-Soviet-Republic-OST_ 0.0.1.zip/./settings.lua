data:extend({
    {
        type = "bool-setting",
        name = "mute",
        setting_type = "startup",
        localised_name = "mute",
        default_value = false
    },
    {
        type = "bool-setting",
        name = "legacy_resources",
        setting_type = "startup",
        localised_name = "legacy-resources",
        default_value = false
    },
})
