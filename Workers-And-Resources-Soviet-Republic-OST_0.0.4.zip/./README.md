# Workers & Resources Soviet Republic Original Sound track Factorio Version

Game by 3Division

Original music by Rotem Hecht

All right to music belong to 3DVISION s.r.o.

[3Division](https://store.steampowered.com/curator/33193263)

https://store.steampowered.com/curator/33193263